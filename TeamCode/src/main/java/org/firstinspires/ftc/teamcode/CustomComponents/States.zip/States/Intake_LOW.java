package org.firstinspires.ftc.teamcode.CustomComponents.States;

import org.firstinspires.ftc.teamcode.Core.DefaultComponents.StateMachine.State;

public class Intake_LOW extends State {
}
