package org.firstinspires.ftc.teamcode.TeamCore.CoreTests.VirtualDevices;

import androidx.annotation.NonNull;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorController;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;

import org.firstinspires.ftc.robotcore.external.navigation.Rotation;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;

public class V_DcMotor implements DcMotor {
    //------------------------------------------------------------------------------------------------
    // State
    //------------------------------------------------------------------------------------------------

    protected DcMotorController      controller = null;
    protected int                    portNumber = -1;
    protected Direction              direction  = Direction.FORWARD;
    protected MotorConfigurationType motorType  = null;

    //------------------------------------------------------------------------------------------------
    // Construction
    //------------------------------------------------------------------------------------------------

    /**
     * Constructor
     *
     * @param controller DC motor controller this motor is attached to
     * @param portNumber portNumber position on the controller
     */
    public V_DcMotor(DcMotorController controller, int portNumber) {
        this(controller, portNumber, Direction.FORWARD);
    }

    /**
     * Constructor
     *
     * @param controller DC motor controller this motor is attached to
     * @param portNumber portNumber port number on the controller
     * @param direction direction this motor should spin
     */
    public V_DcMotor(DcMotorController controller, int portNumber, Direction direction) {
        this(controller, portNumber, direction, MotorConfigurationType.getUnspecifiedMotorType());
    }

    /**
     * Constructor
     *
     * @param controller DC motor controller this motor is attached to
     * @param portNumber portNumber port number on the controller
     * @param direction direction this motor should spin
     * @param motorType the type we know this motor to be
     */
    public V_DcMotor(DcMotorController controller, int portNumber, Direction direction, @NonNull MotorConfigurationType motorType) {
        this.controller = controller;
        this.portNumber = portNumber;
        this.direction = direction;
        this.motorType = motorType;

        // Clone the initial assigned motor type. This disconnects any subsequent modifications in the
        // fields of the type from the type used here at construction, which is usually / often the master
        // SDK instance for a given type, which ought not to be messed with.
        controller.setMotorType(portNumber, motorType.clone());
    }

    //------------------------------------------------------------------------------------------------
    // HardwareDevice interface
    //------------------------------------------------------------------------------------------------

    @Override public Manufacturer getManufacturer() {
        return controller.getManufacturer();
    }

    @Override
    public String getDeviceName() {
        return "Virtual DcMotor";
    }

    @Override
    public String getConnectionInfo() {
        return controller.getConnectionInfo() + "; port " + portNumber;
    }

    @Override
    public int getVersion() {
        return 1;
    }

    @Override
    public void resetDeviceConfigurationForOpMode() {
        this.setDirection(Direction.FORWARD);
        this.controller.resetDeviceConfigurationForOpMode(portNumber);
    }

    @Override
    public void close() {
        setPowerFloat();
    }

    //------------------------------------------------------------------------------------------------
    // DcMotor interface
    //------------------------------------------------------------------------------------------------

    @Override public MotorConfigurationType getMotorType() {
        return controller.getMotorType(portNumber);
    }

    @Override public void setMotorType(MotorConfigurationType motorType) {
        controller.setMotorType(portNumber, motorType);
    }

    /**
     * Get DC motor controller
     *
     * @return controller
     */
    public DcMotorController getController() {
        return controller;
    }


    /**
     * Set the direction
     * @param direction direction
     */
    synchronized public void setDirection(Direction direction) {
        this.direction = direction;
    }

    /**
     * Get the direction
     * @return direction
     */
    public Direction getDirection() {
        return direction;
    }

    /**
     * Get port number
     *
     * @return portNumber
     */
    public int getPortNumber() {
        return portNumber;
    }

    /**
     * Set the current motor power
     *
     * @param power from -1.0 to 1.0
     */
    synchronized public void setPower(double power) {
        // Power must be positive when in RUN_TO_POSITION mode : in that mode, the
        // *direction* of rotation is controlled instead by the relative positioning
        // of the current and target positions.
        if (getMode() == RunMode.RUN_TO_POSITION) {
            power = Math.abs(power);
        } else {
            power = adjustPower(power);
        }
        internalSetPower(power);
    }

    protected void internalSetPower(double power) {
        controller.setMotorPower(portNumber, power);
        // do not remove because it is easier if we modify dcMotorController directly

    }

    /**
     * Get the current motor power
     *
     * @return scaled from -1.0 to 1.0
     */
    synchronized public double getPower() {
        double power = controller.getMotorPower(portNumber);
        if (getMode() == RunMode.RUN_TO_POSITION) {
            power = Math.abs(power);
        } else {
            power = adjustPower(power);
        }
        return power;
    }

    /**
     * Is the motor busy?
     *
     * @return true if the motor is busy
     */
    public boolean isBusy() {
        return controller.isBusy(portNumber);
    }

    @Override
    public synchronized void setZeroPowerBehavior(ZeroPowerBehavior zeroPowerBehavior) {
        controller.setMotorZeroPowerBehavior(portNumber, zeroPowerBehavior);
    }

    @Override
    public synchronized ZeroPowerBehavior getZeroPowerBehavior() {
        return controller.getMotorZeroPowerBehavior(portNumber);
    }

    /**
     * Allow motor to float
     */
    @Deprecated
    public synchronized void setPowerFloat() {
        setZeroPowerBehavior(ZeroPowerBehavior.FLOAT);
        setPower(0.0);
    }

    /**
     * Is motor power set to float?
     *
     * @return true of motor is set to float
     */
    public synchronized boolean getPowerFloat() {
        return getZeroPowerBehavior() == ZeroPowerBehavior.FLOAT && getPower() == 0.0;
    }

    /**
     * Set the motor target position, using an integer. If this motor has been set to REVERSE,
     * the passed-in "position" value will be multiplied by -1.
     *
     *  @param position range from Integer.MIN_VALUE to Integer.MAX_VALUE
     *
     */
    synchronized public void setTargetPosition(int position) {
        position = adjustPosition(position);
        internalSetTargetPosition(position);
    }

    protected void internalSetTargetPosition(int position) {
        controller.setMotorTargetPosition(portNumber, position);
    }

    /**
     * Get the current motor target position. If this motor has been set to REVERSE, the returned
     * "position" will be multiplied by -1.
     *
     * @return integer, unscaled
     */
    synchronized public int getTargetPosition() {
        int position = controller.getMotorTargetPosition(portNumber);
        return adjustPosition(position);
    }

    /**
     * Get the current encoder value, accommodating the configured directionality of the motor.
     *
     * @return double indicating current position
     */
    synchronized public int getCurrentPosition() {
        int position = controller.getMotorCurrentPosition(portNumber);
        return adjustPosition(position);
    }

    protected int adjustPosition(int position) {
        if (getOperationalDirection() == Direction.REVERSE) position = -position;
        return position;
    }

    protected double adjustPower(double power) {
        if (getOperationalDirection() == Direction.REVERSE) power = -power;
        return power;
    }

    protected Direction getOperationalDirection() {
        return motorType.getOrientation() == Rotation.CCW ? direction.inverted() : direction;
    }

    /**
     * Set the current mode
     *
     * @param mode run mode
     */
    synchronized public void setMode(RunMode mode) {
        mode = mode.migrate();
        internalSetMode(mode);
    }

    protected void internalSetMode(RunMode mode) {
        controller.setMotorMode(portNumber, mode);
    }

    /**
     * Get the current mode
     *
     * @return run mode
     */
    public RunMode getMode() {
        return controller.getMotorMode(portNumber);
    }
}
