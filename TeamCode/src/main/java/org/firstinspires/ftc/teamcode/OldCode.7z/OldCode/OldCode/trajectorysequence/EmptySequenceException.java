package org.firstinspires.ftc.teamcode.OldCode.trajectorysequence;


public class EmptySequenceException extends RuntimeException { }
