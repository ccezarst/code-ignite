package org.firstinspires.ftc.teamcode.TeamCore.CoreTests.VirtualDevices;

public class V_IrSeekerSensor {
}
